
  # M-Train-Data-Module-Full_v3

  This is a code bundle for M-Train-Data-Module-Full_v3. The original project is available at https://www.figma.com/design/NScznghhuasO2oQSVmQyVg/M-Train-Data-Module-Full_v3.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  